#include "ros/ros.h"
#include "std_msgs/String.h"
#include <octomap/octomap.h>
#include <octomap/OcTree.h>
#include <octomap_ros/conversions.h>
#include <tf/transform_datatypes.h>
#include "sensor_msgs/PointCloud2.h"

#define LOOP_RATE 2

//octomap::OcTree tree (0.1);   // declare your octomap at 0.1 resolution
void PointCloudCallBack(const sensor_msgs::PointCloud2::ConstPtr& pointCloud)
{	/*
    octomap::Pointcloud octomap_scan;
	octomap::pointCloud2ToOctomap(*pointCloud,octomap_scan);

	tree.insertPointCloud(octomap_scan);*/
}
	
int main(int argc, char *argv[])
{

    ros::init(argc, argv, "pcl2octo");
	ros::NodeHandle nh;

	ros::Subscriber getPointCloud = nh.subscribe("velodyne_points",1000,PointCloudCallBack);



    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\//\
    // read in your data here either rosbag or pcl
    // http://wiki.ros.org/rosbag/Code%20API#cpp_api
    // http://pointclouds.org/documentation/tutorials/pcd_file_format.php
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

	ros::Rate loop_rate(LOOP_RATE);
	while(ros::ok())
	{
		ros::spinOnce();
		loop_rate.sleep();
	}
 //	   tree.writeBinary("simple_tree.bt");
    return 0;

}
